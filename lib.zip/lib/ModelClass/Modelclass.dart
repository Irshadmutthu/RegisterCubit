class Modelclass {
  String name;
  String email;
  String password;
  Modelclass({required this.name, required this.email, required this.password});
}
