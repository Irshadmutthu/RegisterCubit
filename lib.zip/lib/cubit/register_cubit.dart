import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:registration_cubit/ModelClass/Modelclass.dart';

part 'register_state.dart';

class RegisterCubit extends Cubit<RegisterState> {
  RegisterCubit() : super(RegisterInitial());
  void updatelist() {
    emit(RegisterState(datas: state.datas));
  }
}
