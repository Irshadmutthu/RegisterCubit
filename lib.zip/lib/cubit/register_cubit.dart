import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:registration_cubit/ModelClass/Modelclass.dart';

part 'register_state.dart';

class RegisterCubit extends Cubit<RegisterState> {
  RegisterCubit() : super(RegisterInitial());
  void addtolist(Modelclass model) {
    state.datas.add(model);
    emit(RegisterState(
      datas: state.datas,
    ));
  }

  void updateindex(int indexx) {
    emit(RegisterState(datas: state.datas, index: indexx));
  }

  void delete(int index) {
    state.datas.removeAt(index);
    emit(RegisterState(datas: state.datas));
  }

  void updatedataedit(Modelclass modelclass, int indexedit) {
    state.datas[indexedit] = modelclass;
    emit(RegisterState(datas: state.datas));
  }

  void setDataOnEditField(
      TextEditingController namecontroller,
      TextEditingController emailcontroller,
      TextEditingController passwordcontroller,
      int index) {
    namecontroller.text = state.datas[index].name;
    emailcontroller.text = state.datas[index].email;
    passwordcontroller.text = state.datas[index].password;
  }
}
