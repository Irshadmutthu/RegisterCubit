part of 'register_cubit.dart';

class RegisterState {
  List<Modelclass> datas;
  int? index;
  RegisterState({required this.datas, this.index});
}

class RegisterInitial extends RegisterState {
  RegisterInitial()
      : super(
          datas: [],
        );
}
