part of 'register_cubit.dart';

class RegisterState {
  List<Modelclass> datas;
  RegisterState({required this.datas});
}

class RegisterInitial extends RegisterState {
  RegisterInitial() : super(datas: []);
}
