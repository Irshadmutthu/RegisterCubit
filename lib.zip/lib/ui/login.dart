import 'package:flutter/material.dart';
import 'package:registration_cubit/Validator/validator.dart';
import 'package:registration_cubit/ui/registration.dart';
import 'package:registration_cubit/widgets/custom_elevated_button.dart';
import 'package:registration_cubit/widgets/custom_textformfield.dart';

class Login extends StatelessWidget {
  Login({Key? key}) : super(key: key);
  final _formKey = GlobalKey<FormState>();
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar:
            PreferredSize(child: AppBar(), preferredSize: Size.fromHeight(0)),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Form(
                  key: _formKey,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Custom_textformfield(
                          controller: emailcontroller,
                          autoValidate: AutovalidateMode.onUserInteraction,
                          label: "Email",
                          hint: "Enter your email",
                          keyboardtype: TextInputType.emailAddress,
                          validate: (email) =>
                              Validator.validateEmail(email: email!),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Custom_textformfield(
                          autoValidate: AutovalidateMode.onUserInteraction,
                          controller: passwordcontroller,
                          label: "password",
                          hint: "Enter your password",
                          keyboardtype: TextInputType.visiblePassword,
                          obscureText: true,
                          validate: (psw) =>
                              Validator.validatePassword(password: psw!),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Custom_Elevated_Button(
                              button_name: "Sign_In ",
                              onPressing: () async {
                                if (_formKey.currentState!.validate()) {}
                              }),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Not a user?",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Custom_Elevated_Button(
                                button_name: "Register ",
                                onPressing: () {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (context) => RegisterPage()));
                                }),
                          ],
                        )
                      ],
                    ),
                  ))
            ],
          ),
        ));
  }
}
