import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:registration_cubit/ModelClass/Modelclass.dart';
import 'package:registration_cubit/Validator/validator.dart';
import 'package:registration_cubit/cubit/register_cubit.dart';
import 'package:registration_cubit/ui/registration.dart';
import 'package:registration_cubit/widgets/custom_elevated_button.dart';
import 'package:registration_cubit/widgets/custom_textformfield.dart';

class ProfilePage extends StatelessWidget {
  ProfilePage({
    Key? key,
  }) : super(key: key);

  TextEditingController namecontroller = TextEditingController();
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  bool isSelectedd = false;
  int i = 0;
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => RegisterPage()));
              },
              child: Text("Register"))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: BlocBuilder<RegisterCubit, RegisterState>(
          builder: (context, state) {
            return ListView.builder(
              //shrinkWrap: true,
              itemCount: state.datas.length,
              itemBuilder: (context, index) {
                return Card(
                  child: Column(
                    children: [
                      Container(
                        //height: 140,
                        color: Colors.amber,
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 20, right: 20, top: 20),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text("Name :"),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 15),
                                    child: Text(state.datas[index].name),
                                  )
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text("Email :"),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 15),
                                    child: Text(state.datas[index].email),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text("Password : "),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 15),
                                    child: Text(state.datas[index].password),
                                  )
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  IconButton(
                                      color: Colors.white,
                                      onPressed: () {
                                        context
                                            .read<RegisterCubit>()
                                            .updateindex(index);
                                        ;
                                        context
                                            .read<RegisterCubit>()
                                            .setDataOnEditField(
                                                namecontroller,
                                                emailcontroller,
                                                passwordcontroller,
                                                index);
                                      },
                                      icon: Icon(Icons.edit)),
                                  IconButton(
                                      color: Colors.red,
                                      onPressed: () {
                                        AlertDialog alert = AlertDialog(
                                          title: Text("Delete Confirmations"),
                                          content: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text(
                                                  "This will deltete this profile"),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 10),
                                                child: Text(
                                                  "Are you sure to Delete?",
                                                  style: TextStyle(
                                                      color: Colors.red),
                                                ),
                                              )
                                            ],
                                          ),
                                          actions: [
                                            TextButton(
                                              onPressed: () {
                                                // state.datas.removeAt(index);
                                                // context
                                                //     .read<RegisterCubit>()
                                                //     .updatelist();
                                                context
                                                    .read<RegisterCubit>()
                                                    .delete(index);
                                                Navigator.pop(context);
                                              },
                                              child: Text("YES",
                                                  style: TextStyle(
                                                      color: Colors.red,
                                                      fontWeight:
                                                          FontWeight.bold)),
                                            ),
                                            TextButton(
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                                child: Text("NO",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold)))
                                          ],
                                        );
                                        showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return alert;
                                            });
                                      },
                                      icon: Icon(Icons.delete))
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                      if (index == state.index)
                        Container(
                          height: 200,
                          color: Colors.amber,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10, right: 10),
                            child: Form(
                              key: _formKey,
                              child: Column(
                                children: [
                                  Custom_textformfield(
                                      validate: (value) =>
                                          Validator.validateName(name: value!),
                                      autoValidate:
                                          AutovalidateMode.onUserInteraction,
                                      controller: namecontroller,
                                      label: "Name",
                                      hint: "Enter Name",
                                      keyboardtype: TextInputType.name),
                                  Custom_textformfield(
                                      autoValidate:
                                          AutovalidateMode.onUserInteraction,
                                      validate: (value) =>
                                          Validator.validateEmail(
                                              email: value!),
                                      controller: emailcontroller,
                                      label: "Email",
                                      hint: "Enter Email",
                                      keyboardtype: TextInputType.name),
                                  Custom_textformfield(
                                      autoValidate:
                                          AutovalidateMode.onUserInteraction,
                                      validate: (value) =>
                                          Validator.validatePassword(
                                              password: value!),
                                      controller: passwordcontroller,
                                      label: "Password",
                                      hint: "Enter Password",
                                      keyboardtype: TextInputType.name),
                                  Custom_Elevated_Button(
                                      button_name: "submit",
                                      onPressing: () {
                                        if (_formKey.currentState!.validate()) {
                                          Modelclass newmodel = Modelclass(
                                              name: namecontroller.text,
                                              email: emailcontroller.text,
                                              password:
                                                  passwordcontroller.text);
                                          context
                                              .read<RegisterCubit>()
                                              .updatedataedit(newmodel, index);
                                        }
                                      })
                                ],
                              ),
                            ),
                          ),
                        ),
                      Container(),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
