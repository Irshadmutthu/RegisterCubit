import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:registration_cubit/ModelClass/Modelclass.dart';
import 'package:registration_cubit/Validator/validator.dart';
import 'package:registration_cubit/cubit/register_cubit.dart';
import 'package:registration_cubit/ui/profile.dart';
import 'package:registration_cubit/widgets/custom_elevated_button.dart';
import 'package:registration_cubit/widgets/custom_textformfield.dart';

class RegisterPage extends StatelessWidget {
  RegisterPage({Key? key}) : super(key: key);

  final _formKey = GlobalKey<FormState>();
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  TextEditingController namecontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(child: AppBar(), preferredSize: Size.fromHeight(0)),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Custom_textformfield(
                controller: namecontroller,
                autoValidate: AutovalidateMode.onUserInteraction,
                label: "Name",
                hint: "Enter your name",
                keyboardtype: TextInputType.name,
                validate: (name) => Validator.validateName(name: name!),
              ),
              SizedBox(
                height: 8,
              ),
              Custom_textformfield(
                controller: emailcontroller,
                autoValidate: AutovalidateMode.onUserInteraction,
                label: "Email",
                hint: "Enter your email",
                keyboardtype: TextInputType.emailAddress,
                validate: (email) => Validator.validateEmail(email: email!),
              ),
              SizedBox(
                height: 8,
              ),
              Custom_textformfield(
                controller: passwordcontroller,
                autoValidate: AutovalidateMode.onUserInteraction,
                obscureText: true,
                label: "password",
                hint: "Enter your password",
                keyboardtype: TextInputType.visiblePassword,
                validate: (password) =>
                    Validator.validatePassword(password: password!),
              ),
              SizedBox(
                height: 8,
              ),
              BlocBuilder<RegisterCubit, RegisterState>(
                builder: (context, state) {
                  return Custom_Elevated_Button(
                      button_name: "Register",
                      onPressing: () {
                        if (_formKey.currentState!.validate()) {
                          Modelclass newmodel = Modelclass(
                              name: namecontroller.text,
                              email: emailcontroller.text,
                              password: passwordcontroller.text);
                          context.read<RegisterCubit>().addtolist(newmodel);

                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ProfilePage()));
                        }
                      });
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
