// import 'dart:js';

import 'package:flutter/material.dart';

void Customsnackbar({required Widget message, required BuildContext context}) {
  var snack = SnackBar(
    // elevation: 10,
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    content: message,
  );
  ScaffoldMessenger.of(context).showSnackBar(snack);
}
