import 'package:flutter/material.dart';

class Custom_textformfield extends StatelessWidget {
  TextEditingController controller;
  Color? textcolor;
  String label;
  String? hint;
  TextInputType keyboardtype;
  FormFieldValidator<String>? validate;
  AutovalidateMode? autoValidate;
  bool? obscureText;

  Custom_textformfield({
    Key? key,
    required this.controller,
    this.textcolor,
    required this.label,
    required this.hint,
    required this.keyboardtype,
    this.validate,
    this.autoValidate,
    this.obscureText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFormField(
        controller: controller,
        obscureText: obscureText ?? false,
        validator: validate,
        autovalidateMode: autoValidate,
        keyboardType: keyboardtype,
        style: TextStyle(color: textcolor),
        decoration: InputDecoration(
          labelStyle: TextStyle(color: Colors.black),
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: Colors.grey, fontSize: 22),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(50.0),
          ),
          contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10),
        ));
  }
}
